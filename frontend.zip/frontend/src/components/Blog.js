import React, { Component } from 'react';

class Blog extends Component {
  render() {
    return (
      <div className="Blog">
          <h1>BLOG</h1>
      </div>
    );
  }
}

export default Blog;
