import { combineReducers } from 'redux'

import {
  ADD_EXAMPLE,
} from '../actions'

function example (state = {}, action) {
  switch (action.type) {
    default :
      return state
  }
}

export default combineReducers({
  example
})